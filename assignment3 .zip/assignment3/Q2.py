#GCD Final

# maping digits for bases above 10 (like ABC stuff)
digits = "0123456789ABCDEF"

def base_to_decimal(number, base):
    """Convert a number from any base to decimal (base 10)."""
    decimal_value = 0
    for i, digit in enumerate(reversed(number)):
        decimal_value += digits.index(digit.upper()) * (base ** i)
    return decimal_value

def decimal_to_base(number, base):
    """Convert a decimal (base 10) number to any base."""
    if number == 0:
        return "0"
    result = ""
    while number > 0:
        result = digits[number % base] + result
        number //= base
    return result

def convert_number(number, from_base, to_base):
    """Convert a number from one base to another base."""
    # converting the number to decimal (base 10)
    decimal_value = base_to_decimal(number, from_base)
    # converting from decimal to the base
    return decimal_to_base(decimal_value, to_base)

# Example usage:
if __name__ == "__main__":
    # Example 1: Convert 87237823679 to base 15
    number = "87237823679"
    from_base = 10
    to_base = 15
    print(f"{number} in base {from_base} to base {to_base}: {convert_number(number, from_base, to_base)}")

    # Example 2: Convert 123456789ABCDEF16 to base 10
    number = "123456789ABCDEF"
    from_base = 16
    to_base = 10
    print(f"{number} in base {from_base} to base {to_base}: {convert_number(number, from_base, to_base)}")

    # Example 3: Convert 111111101110110110111110111011112 to base 16
    number = "111111101110110110111110111011112"
    from_base = 2
    to_base = 16
    print(f"{number} in base {from_base} to base {to_base}: {convert_number(number, from_base, to_base)}")

    Var1 = input("Enter a number to conver to a base:  ") 
    Var2 = int(input("What base is this number in?:  "))
    Var3 = int(input("What base to you what it converted to (must be between 2 and 16)?:  "))

    number = Var1
    from_base = Var2
    to_base = Var3
    print(f"{number} in base {from_base} to base {to_base}: {convert_number(number, from_base, to_base)}")


