
# performs the addition of two matrices a and b that are given as arguments
def matrix_add(a,b):
    #Check if the matrices are the same size
    if len(a) != len(b):
        return "The matrices are not the same size. You cannot perform addition."
    else:
        for i in a:
           dim_a = len(i)
        for j in b:
           dim_b = len(j)
        if dim_a != dim_b:
            return "The matrices are not the same size. You cannot perform addition."
    
    # perform the addition 
    for i in range(0,len(a)):
       for j in range(0,len(b)):
            a[j][i] += b[j][i]
    return a


# performs the subtraction of two matrices a and b that are given as arguments
def matrix_sub(a,b):
    #Check if the matrices are the same size
    if len(a) != len(b):
        return "The matrices are not the same size. You cannot perform subtraction."
    else:
        for i in a:
           dim_a = len(i)
        for j in b:
           dim_b = len(j)
        if dim_a != dim_b:
            return "The matrices are not the same size. You cannot perform subtraction."
    
    # perform the subtraction
    for i in range(0,len(a)):
       for j in range(0,len(b)):
            a[j][i] -= b[j][i]
    return a

# performs the multiplication of two matrices a and b that are given as arguments
def matrix_mult(a,b):

    # check if the number of columns in matrix a is the same as the number of rows in b. If not, multiplication cannot be done.
    for i in a:
        dim_a = len(i)
    if len(b) != dim_a:
        return "You cannot perform matrix multiplication with these two matrices"
    else:
        ans = []
        
        #iterate through rows of a
        for i in range(len(a)):
            rows = [] # initialize rows to be appended to ans

            # iterate through columns of b
            for j in range(len(b[0])):
                cols = 0

                # iterate again through a
                for k in range(len(a)):
                    cols += a[i][k] * b[k][j] # perform the calculation, multiplying the row of a with corresponding column in b
                rows.append(cols)
            ans.append(rows)

        return ans

                
# Reads in the file and formats the matrices to prep them for calculations
def format_matrix():
    
    # read in the txt file
    file = open("matrices.txt","r")

    # convert the lines into elements of strings
    rows = []
    for el in file:
        split_el = el.split(",") # split up values by comma
        split_el = el.strip("\n") #remove \n from elements
        rows.append(split_el) #append elements to row array

    # turn the comma seperated strings into integer rows
    arr = []
    for i in rows:
        if i != "":
            row = [int(x) for x in i.split(",")]
            arr.append(row)
        else:
            array1_rows = rows.index(i) # determines the number of row in first array
            array2_rows = len(rows) - rows.index(i) - 1 # determines the number of rows in second array

    # split the single matrix into two matrices
    a = arr[:array1_rows] # anything before line break is first array
    b = arr[array1_rows:] #anything after line break is second array
    return a, b

# call function to initialize matrices
a = format_matrix()[0]
b = format_matrix()[1]

#print(matrix_add([[1,2,6],[4,3,7]],[[1,2],[4,3]]))  <---- Sample matrices to make addition work
#print(matrix_sub([[1,2],[4,3]],[[2,2],[4,3]])) <---- Sample matrices to make subtraction work
print(matrix_mult(a,b)) #<--- Multiplication using the txt file matrices
