
# Calculates the gcd of two numbers a and b using the Euclidean algorithm
def gcd_calc(a,b):
    
    # performs the following loop until b = 0 at which point a is the gcd
    while b > 0:
        rem = a % b # calculates the remainder of the two numbers entered
        a = b 
        b = rem
    return a

# calculates the gcd for any sized array of numbers
def gcd(arr):
    num1 = arr[0] 
    num2 = arr[1]
    gcd = gcd_calc(num1,num2) # calculate the gcd of first two numbers using gcd_calc function

    # repeatedly call the gcd_calc function, updating the value for each iteration of the array
    for i in range(len(arr)):
        gcd = gcd_calc(gcd,arr[i])

    return gcd

# print results
print(gcd([2,4,2042]))
print(gcd([330,1505,3289,15301]))
