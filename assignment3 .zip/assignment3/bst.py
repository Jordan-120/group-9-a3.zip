from bstnode import BSTNode
import random

"""
The code to implement a binary search tree. You must fill in all of the methods
below (and remove the `pass`) as explained in the comments and by the usage in
main.py.

Feel free to add any additional helper functions, but DO NOT modify the names or
required inputs of the functions as indicated. Adding optional inputs is fine, however.

NOTE: The tree, upon creation, has no nodes; the root is empty. Do not forget to update
self.root when the root changes (e.g. inserting the first node into an empty tree or
removing the last node).

"""

#class BST:
#    def __init__(self):
#        self.root = None

    # Return the root of the BST
#    def get_root(self) -> BSTNode:
#        return self.root

    # This node is purely for the unit tests; you don't need it as you can use self.root here
#   def update_root(self, node: BSTNode) -> None:
#       self.root = node

class BST:
    def __init__(self):
        self.root = None

    def get_root(self) -> BSTNode:
        return self.root

    def update_root(self, node: BSTNode) -> None:
        self.root = node


    """
    Recursively search for the key in `key` using the binary search tree property.
    Recall that this property says, for any specific node, all of its left children's keys
    are smaller, and all of its right children's keys are larger.
    
    Args:
        key: integer key that you are searching for
        node: the node we are currently checking
        
    Return:
        Returns the BSTNode with key equal to `key` if found, or None otherwise
    """

#    def search(self, key: int, node: BSTNode) -> BSTNode|None:
#        pass

    def search(self, key: int, node: BSTNode) -> BSTNode|None:
        if node == None or node.key == key:
            return node
        if key < node.key:
            return self.search(key, node.left_child)
        else:
            return self.search(key, node.right_child)


    """
    Insert the given node at the correct position in the binary search
    tree using the BST property (defined in search() above). If the next
    node you would visit doing this search is None, that's where the node
    should be inserted. If the node already exists, do nothing.
    
    You will be inserting into the tree a new instance of BSTNode(key).
    
    If your tree is empty, don't forget to update the root!

    Args:
        key: integer key that you are adding to the tree

    Return:
        None
    """

#    def insert(self, key: int) -> None:
#        pass

    def insert(self, key: int) -> None:
        newNode = BSTNode(key)
        if self.root == None:
            self.root = newNode
            return
        cur = self.root
        while True:
            if key < cur.key:
                if cur.left_child == None:
                    cur.left_child = newNode
                    newNode.parent = cur
                    return
                cur = cur.left_child
            elif key > cur.key:
                if cur.right_child == None:
                    cur.right_child = newNode
                    newNode.parent = cur
                    return
                cur = cur.right_child
            else:
                return

    """
    Delete a node with given `key` from the tree.

    Deletion is the most complex task in a binary search tree. First, you must search for
    the node you wish to delete. If it doesn't exist, we're done - nothing to delete.
    
    If it does, and it is the only node (it is the root AND has no children), update self.root to None.
    
    Otherwise, there are three situations to consider:
        1) The node has no children (is a leaf node). Update its parent (if it exists) to no
        longer point to it and it is now removed from the tree.
        2) The node has one child. Have that child point to the current node's parent (if it exists)
        and update the current node's parent to point to that same child. You are updating the
        parent/child relationships to essentially "remove" reference to this current node, skipping
        over it.
        3) (BONUS MARKS) The node has two children. Find this node's successor. That means find the minimum
        of node.right_child. Replace this node's key with that one. Now look down node.right_child to delete
        the key you just found. It will always be a leaf or only have a right child (why?)
    
    After deleting, don't forget to update self.root if it has changed!
    
    Args:
        key: integer key that you are deleting from the tree

    Returns:
        The key that was asked to be deleted, and if it is not in the tree, return None
    """

    # Helper function to find the smallest key starting at node
#    def minimum(self, node: BSTNode) -> BSTNode:
#        pass

#    def delete(self, key: int) -> int|None:
#        pass

    def minimum(self, node: BSTNode) -> BSTNode:
        cur = node
        while cur.left_child != None:
            cur = cur.left_child
        return cur

    def delete(self, key: int) -> int|None:
        node = self.search(key, self.root)
        if node == None:
            return None

        if node.left_child == None and node.right_child == None:
            if node == self.root:
                self.root = None
            elif node.parent.left_child == node:
                node.parent.left_child = None
            else:
                node.parent.right_child = None

        elif node.left_child == None or node.right_child == None:
            child = node.left_child if node.left_child else node.right_child
            if node == self.root:
                self.root = child
            elif node.parent.left_child == node:
                node.parent.left_child = child
            else:
                node.parent.right_child = child
            child.parent = node.parent

        else:
            succ = self.minimum(node.right_child)
            node.key = succ.key
            self.delete(succ.key)

        return key


    """
    Recursively perform the given traversal of the tree.
    
    Preorder: Visit node, left child, right child in that order
    Inorder: Visit left child, node, right child in that order
    Postorder: Visit left child, right child, node in that order
    
    Args:
        node: node we're looking to traverse from.
        
    Returns:
        A list of the keys of the nodes visited.
    """

#    def preorder(self, node: BSTNode) -> list[int]:
#        pass

#    def inorder(self, node: BSTNode) -> list[int]:
#        pass

#    def postorder(self, node: BSTNode) -> list[int]:
#        pass

#the orders (pre, in, post)
    def preorder(self, node: BSTNode) -> list[int]:
        if node == None:
            return []
        result = [node.key]
        result += self.preorder(node.left_child)
        result += self.preorder(node.right_child)
        return result

    def inorder(self, node: BSTNode) -> list[int]:
        if node == None:
            return []
        result = self.inorder(node.left_child)
        result.append(node.key)
        result += self.inorder(node.right_child)
        return result

    def postorder(self, node: BSTNode) -> list[int]:
        if node == None:
            return []
        result = self.postorder(node.left_child)
        result += self.postorder(node.right_child)
        result.append(node.key)
        return result

#taken as you provided
class BSTNode:
    def __init__(self, key: int):
        self.key = key
        self.left_child: BSTNode|None = None
        self.right_child: BSTNode|None = None
        self.parent: BSTNode|None = None

        
# Empty BST
tree = BST()

# inserting into BST (rando numbers)
random_keys = random.sample(range(1, 101), 15)
for key in random_keys:
    tree.insert(key)

#Here is the printing
print("Inserted Keys:", random_keys)
print("Inorder Traversal:", tree.inorder(tree.get_root()))
print("Preorder Traversal:", tree.preorder(tree.get_root()))
print("Postorder Traversal:", tree.postorder(tree.get_root()))

#search function with print
search_key = random.choice(random_keys)
print(f"Searching for {search_key}: Found {tree.search(search_key, tree.get_root()) is not None}")

#delete function with print
delete_key = random.choice(random_keys)
print(f"Deleting {delete_key}: Deleted {tree.delete(delete_key)}")
print("Inorder Traversal After Deletion:", tree.inorder(tree.get_root()))

